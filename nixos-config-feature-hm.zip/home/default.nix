# home/default.nix
# Home Manager configuration for user borba (fase 2).
# Manages the previously tmpfiles-linked dotfiles with home.file / xdg.configFile.
# Source of truth remains the external ~/dotfiles repo (clone/stow target).
# Configs are preserved 1:1; only the linking mechanism moved to HM.
{
  config,
  lib,
  pkgs,
  pkgs-unstable,
  hostname,
  inputs,
  ...
}: let
  username = "borba";
  homeDir = "/home/${username}";
  dotfilesDir = "${homeDir}/dotfiles";

  # Programs whose ~/.config/<name> is fully managed by a directory in the
  # external dotfiles repo. Mirrors the previous global `dotfilePrograms` list.
  # Host-specific extras (lazygit, yazi, niri/input.kdl) are layered in the
  # per-host NixOS modules via home-manager.users.<name>.
  configPrograms = [
    "tmux"
    "zellij"
    "alacritty"
    "wezterm"
    "niri"
    "waybar"
    "helix"
    "git"
    "zsh"
    "wlr-which-key"
    "nvim"
    "bat"
    "btop"
    "ripgrep"
    "oh-my-posh"
  ];

  # Helper: link an entire XDG config directory from the external dotfiles tree.
  # Using `source` makes HM own the symlink; activation is transactional and
  # reversible via generations (unlike the old systemd.tmpfiles L+ rules).
  mkConfigLink = name: {
    name = name;
    value = {
      source = "${dotfilesDir}/${name}/.config/${name}";
      recursive = true;
    };
  };
in {
  # ------------------------------------------------------------------
  # Identity
  # ------------------------------------------------------------------
  home.username = username;
  home.homeDirectory = homeDir;
  home.stateVersion = "26.05";

  # ------------------------------------------------------------------
  # Shell
  # ------------------------------------------------------------------
  # .zshenv must live outside ZDOTDIR; everything else is under
  # $XDG_CONFIG_HOME/zsh (see the external zsh/.zshenv).
  home.file.".zshenv".source = "${dotfilesDir}/zsh/.zshenv";

  # ------------------------------------------------------------------
  # XDG config directories (the previous systemd.tmpfiles.rules payload)
  # ------------------------------------------------------------------
  xdg.enable = true;
  xdg.configFile = builtins.listToAttrs (map mkConfigLink configPrograms);

  # ------------------------------------------------------------------
  # Minimal programs.* enablement where it adds real value without
  # conflicting with the hand-written configs we just linked.
  # ------------------------------------------------------------------
  # Keep zsh as login shell (set also on the NixOS side for consistency).
  programs.zsh.enable = true;
  # Do NOT set programs.zsh.*Config or oh-my-zsh etc — the external
  # ZDOTDIR tree already provides .zshrc, plugins, prompt, etc.

  # direnv was already enabled system-wide; HM integration is nice-to-have
  # and does not touch any of the linked files.
  programs.direnv = {
    enable = true;
    nix-direnv.enable = true;
    enableZshIntegration = true;
  };

  # ------------------------------------------------------------------
  # Packages that are purely user-facing can live here later.
  # For this surgical phase we leave environment.systemPackages alone.
  # ------------------------------------------------------------------
  home.packages = [ ];

  # ------------------------------------------------------------------
  # Session variables (mirrors some of what .zshenv / misc.kdl set)
  # ------------------------------------------------------------------
  home.sessionVariables = {
    EDITOR = "hx";
    VISUAL = "hx";
  };
}
