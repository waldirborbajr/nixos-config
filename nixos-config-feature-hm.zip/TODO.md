# TODO

> As duas linhas antigas deste arquivo (`stow -D waybar sway` / `stow -R
> i3status`) referenciavam `stow` e o stack `sway`/`i3status`, que não são
> mais usados neste repo. Dotfiles agora são gerenciados pelo Home Manager
> (fase 2 — ver `home/default.nix` e os blocos `home-manager.users` nos
> hosts). O compositor atual continua `niri` + `waybar`.

- [ ] Confirmar boot mode real do `dell1564` (`ls /sys/firmware/efi`) — o
      comentário em `hosts/dell1564/default.nix` assume BIOS legado/GRUB
      mas ainda não foi confirmado no hardware.
- [ ] Confirmar o device do GRUB (`hosts/dell1564/default.nix`, atualmente
      hardcoded como `/dev/sda`) com `lsblk -f` no Dell antes do próximo
      rebuild do zero.
- [ ] WiFi Broadcom BCM4312 no `dell1564`: driver `b43` carrega mas
      `ucode15.fw` não é encontrado em runtime — investigar achatamento do
      path do firmware (ver histórico em memória/anotações do host).
- [x] Fase 2: migração para home-manager (dotfiles movidos de
      `systemd.tmpfiles.rules` para `home.file` / `xdg.configFile` via
      `home/default.nix` + overlays por host).
- [ ] Avaliar se `.sops.yaml` deveria existir (hoje ausente — ver nota no
      relatório de auditoria) para centralizar os recipients age por host.
- [ ] Fase 3 (futuro): migrar mais opções para módulos nativos do HM
      (`programs.git`, `programs.helix`, `programs.tmux`, etc.) onde o
      ganho de integração justificar, sem perder o conteúdo atual dos
      arquivos em `~/dotfiles`.
