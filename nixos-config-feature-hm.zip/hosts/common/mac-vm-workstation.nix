# hosts/common/mac-vm-workstation.nix
#
# Base compartilhada pelas VMs Mac (macutm e macvmf). Só o agente de guest
# da VM (UTM vs VMware Fusion) e o hardware-configuration.nix continuam
# específicos de cada host — o resto é idêntico entre os dois.
{ lib, pkgs, common, ... }:
let
  inherit (common) dotfilesDir username;
in {
  # ==================== BOOT ====================
  boot.loader.systemd-boot.enable = true;
  boot.loader.efi.canTouchEfiVariables = true;
  boot.kernelParams = [ "mitigations=off" ]; # ajuda em VMs

  # ==================== CONTAINERS ====================
  virtualisation.podman = {
    enable = true;
    dockerCompat = true;
    defaultNetwork.settings.dns_enabled = true;
  };
  virtualisation.containers.enable = true;

  # ==================== KEYBOARD ====================
  console.keyMap = "us";
  services.xserver.xkb.layout = "us";
  services.xserver.xkb.variant = "mac";

  # ==================== PACKAGES ====================
  environment.systemPackages = with pkgs; [
    zellij yazi jq just duf psmisc asciinema
    lazygit jujutsu lazyjj

    flameshot vlc

    emacs emacsPackages.vterm emacsPackages.pbcopy

    dex autorandr xkill

    brightnessctl playerctl pciutils pavucontrol ffmpeg

    podman lazydocker gcc gnumake cmake gdb glibc libgcc libcxx

    rust-analyzer rustfmt
    lua-language-server stylua
    gotools golangci-lint-langserver

    python3Packages.python-lsp-server black taplo marksman
  ];

  programs.firefox.enable = lib.mkDefault true;

  # ==================== HOME MANAGER (host-specific, fase 2) ====================
  # Extra config dirs + niri input variant for Mac VMs.
  # These merge with the common home/default.nix via attribute set merge.
  home-manager.users.${username} = {
    xdg.configFile = {
      # lazygit & yazi (previously host-only in the old tmpfiles list)
      "lazygit" = {
        source = "${dotfilesDir}/lazygit/.config/lazygit";
        recursive = true;
      };
      # yazi has no tree in the current dotfiles repo; keep the entry so
      # that when the config appears under ~/dotfiles/yazi it is picked up
      # without another rebuild of this module. If the dir is missing HM
      # will warn at activation time — same behaviour as the old L+ rule.
      "yazi" = {
        source = "${dotfilesDir}/yazi/.config/yazi";
        recursive = true;
      };
      # Override the niri input fragment for Mac keyboard / trackpad in VMs
      "niri/input.kdl".source = "${dotfilesDir}/niri/.config/niri/input-mac.kdl";
    };
  };
}
