{
  description = "Master Flake for Borba NixOS Config";

  inputs = {
    nixpkgs.url = "github:NixOS/nixpkgs/nixos-26.05";
    nixpkgs-unstable.url = "github:NixOS/nixpkgs/nixos-unstable";

    # Neovim
    neovim-nightly-overlay = {
      url = "github:nix-community/neovim-nightly-overlay";
      inputs.nixpkgs.follows = "nixpkgs-unstable";
    };

    # 🔐 secrets management
    sops-nix.url = "github:Mic92/sops-nix";

    # 🏠 home-manager (fase 2)
    home-manager = {
      url = "github:nix-community/home-manager/release-26.05";
      inputs.nixpkgs.follows = "nixpkgs";
    };

    # 🔎 nix-index-database — prebuilt "command not found" DB (all hosts)
    nix-index-database = {
      url = "github:nix-community/nix-index-database";
      inputs.nixpkgs.follows = "nixpkgs";
    };

    # 🎨 treefmt-nix — repo-wide formatter, exposto via `nix fmt`
    treefmt-nix = {
      url = "github:numtide/treefmt-nix";
      inputs.nixpkgs.follows = "nixpkgs";
    };

    # 🦀 rust-overlay — fornece `pkgs.rust-bin` (toolchain unificado,
    #    com rustc/cargo/rust-analyzer/rustfmt/clippy SEMPRE sincronizados).
    #    Sem isso, `rust-bin` fica undefined nos módulos.
    rust-overlay = {
      url = "github:oxalica/rust-overlay";
      inputs.nixpkgs.follows = "nixpkgs";
    };
  };

  outputs = {
    self,
    nixpkgs,
    nixpkgs-unstable,
    sops-nix,
    home-manager,
    treefmt-nix,
    rust-overlay,
    ...
  } @ inputs: let
    # 🖥️  Hosts NixOS (gerenciam sistema + home-manager embutido)
    mkHost = {
      hostname,
      system,
    }:
      nixpkgs.lib.nixosSystem {
        inherit system;

        specialArgs = {
          inherit inputs hostname;

          pkgs-unstable = import nixpkgs-unstable {
            inherit system;
            config.allowUnfree = true;
          };
        };

        modules = [
          # 🔐 SOPS module (global)
          sops-nix.nixosModules.sops

          # 🏠 Home Manager (fase 2)
          home-manager.nixosModules.home-manager

          # 🦀 rust-overlay — torna `pkgs.rust-bin` disponível em
          #    todos os módulos do sistema (incluindo development/rust.nix).
          {
            nixpkgs.overlays = [
              rust-overlay.overlays.default
            ];
          }

          ./configuration.nix
          ./hosts/${hostname}/configuration.nix # ← macutm ou macvmf, nunca os dois juntos
          ./hosts/${hostname}/hardware-configuration.nix # ← idem
        ];
      };

    # 🍎 home-manager standalone (macOS físico) — sem gerenciar o sistema,
    # só pacotes + dotfiles (zsh, git, helix, tmux, wezterm, etc).
    mkMacHome = {
      hostname,
      system ? "aarch64-darwin",
    }:
      home-manager.lib.homeManagerConfiguration {
        pkgs = import nixpkgs {
          inherit system;
          config.allowUnfree = true;

          # 🦀 rust-overlay também no macOS físico, para o toolchain
          #    Rust ficar sincronizado via home-manager.
          overlays = [
            rust-overlay.overlays.default
          ];
        };

        extraSpecialArgs = {
          inherit inputs hostname;

          pkgs-unstable = import nixpkgs-unstable {
            inherit system;
            config.allowUnfree = true;
          };
        };

        modules = [
          ./home/${hostname}.nix
        ];
      };

    # 🧩 Sistemas suportados pelo formatter/treefmt.
    # Inclui aarch64-darwin para o `nix fmt` funcionar também no MacBook M2.
    supportedSystems = [
      "x86_64-linux"
      "aarch64-linux"
      "aarch64-darwin"
    ];

    # 🌳 Instancia o treefmt para um sistema.
    # A RECURSÃO pelos .nix vem do arquivo ./treefmt.nix — não daqui.
    # Aqui só montamos o wrapper que o `nix fmt` executa.
    treefmtFor = system: let
      pkgs = nixpkgs.legacyPackages.${system};
    in
      (treefmt-nix.lib.evalModule pkgs ./treefmt.nix).config.build.wrapper;
  in {
    nixosConfigurations = {
      dell = mkHost {
        hostname = "dell1564";
        system = "x86_64-linux";
      };

      m2utm = mkHost {
        hostname = "macutm";
        system = "aarch64-linux";
      };

      macvmf = mkHost {
        hostname = "macvmf";
        system = "aarch64-linux";
      };

      mac2011 = mkHost {
        hostname = "mac2011";
        system = "x86_64-linux";
      };
    };

    homeConfigurations = {
      # `home-manager switch --flake .#borba@macbook` no MacBook M2 físico.
      "borba@macbook" = mkMacHome {
        hostname = "macbook";
      };
    };

    # `nix fmt` — mesmo formatter em qualquer host (Linux ou Darwin).
    formatter = nixpkgs.lib.genAttrs supportedSystems treefmtFor;

    # `nix flake check` agora também valida formatação.
    checks = nixpkgs.lib.genAttrs supportedSystems (system: {
      # `config.build.check` é uma FUNÇÃO (self: derivation), não a
      # derivation em si — usa `self` (o flake) como `src` do check.
      # Sem passar `self` aqui, o output vira uma função e o
      # `nix flake check` falha com "is not a derivation".
      formatting =
        (treefmt-nix.lib.evalModule nixpkgs.legacyPackages.${system} ./treefmt.nix).config.build.check self;
    });
  };
}
