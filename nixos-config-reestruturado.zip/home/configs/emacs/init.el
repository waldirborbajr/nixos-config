;;; init.el --- Development environment -*- lexical-binding: t; -*-

(setq gc-cons-threshold (* 256 1024 1024)
      read-process-output-max (* 4 1024 1024)
      process-adaptive-read-buffering nil)

(require 'ansi-color)
(add-hook 'compilation-filter-hook #'ansi-color-compilation-filter)

(add-hook 'emacs-startup-hook
          (lambda () (setq gc-cons-threshold (* 32 1024 1024))))

;; Pacotes vêm 100% do Nix (emacs-vanilla.nix, epkgs.withPackages) — já
;; ficam no load-path, sem precisar de `package-initialize`/MELPA em
;; runtime. Ter DOIS gerenciadores de pacote ativos (Nix + package.el
;; baixando pra ~/.emacs.d/elpa) deixa a ordem do load-path
;; imprevisível — um pacote baixado ali pode sombrear silenciosamente
;; algo embutido do Emacs 30 (o `eglot`, por exemplo) sem erro nenhum
;; aparecer, o que bate com o `:hook` do eglot não disparar sozinho.
(require 'use-package)
(setq use-package-always-ensure nil)

(menu-bar-mode -1)
(tool-bar-mode -1)
(scroll-bar-mode -1)

(set-face-attribute 'default nil :family "JetBrainsMono Nerd Font" :height 080)
(unless (find-font (font-spec :name "JetBrainsMono Nerd Font"))
  (set-face-attribute 'default nil :family "JetBrains Mono"))

(use-package catppuccin-theme
  :config
  (setq catppuccin-flavor 'mocha)
  (load-theme 'catppuccin t))

(require 'uniquify)
(setq uniquify-buffer-name-style 'forward
      indent-tabs-mode nil
  tab-width 2
  standard-indent 2
      custom-file (expand-file-name "custom.el" user-emacs-directory))

(add-hook 'prog-mode-hook
      (lambda ()
    (setq-local indent-tabs-mode nil)
    (setq-local tab-width 2)
    (setq-local standard-indent 2)))

(electric-pair-mode 1)
(show-paren-mode 1)
(save-place-mode 1)
(savehist-mode 1)
(recentf-mode 1)
(global-auto-revert-mode 1)
(add-hook 'prog-mode-hook #'display-line-numbers-mode)
(add-hook 'text-mode-hook #'visual-line-mode)

(use-package vertico
  :demand t
  :config
  (vertico-mode 1))

(use-package orderless
  :custom
  (completion-styles '(orderless basic))
  (completion-category-defaults nil)
  (completion-category-overrides
   '((file (styles partial-completion basic)))))

(use-package marginalia
  :demand t
  :config
  (marginalia-mode 1))

(use-package corfu
  :demand t
  :custom
  (corfu-auto t)
  (corfu-auto-delay 0.15)
  (corfu-auto-prefix 1)
  (corfu-cycle t)
  (corfu-preselect 'prompt)
  :config
  (global-corfu-mode 1))

(global-set-key (kbd "C-c y") #'completion-at-point)

(use-package cape
  :demand t
  :init
  (add-hook 'prog-mode-hook
            (lambda ()
              (add-hook 'completion-at-point-functions #'cape-dabbrev nil t)
              (add-hook 'completion-at-point-functions #'cape-file nil t))))
;; REMOVIDO: (advice-add 'eglot-completion-at-point :around #'cape-wrap-buster)
;; Essa linha travava o carregamento do resto do init.el inteiro: `cape-wrap-buster`
;; não existe de verdade no pacote `cape` (os wrappers reais são cape-wrap-silent,
;; cape-wrap-predicate, cape-wrap-nonexclusive etc.), e mesmo que existisse,
;; `eglot-completion-at-point` ainda não está carregado nesse ponto do arquivo
;; (eglot é `:commands`, carregamento adiado) — `advice-add` em símbolo sem
;; função definida dá erro `void-function` na hora, na carga do init.el, e tudo
;; que vem depois no arquivo (eglot, rust-mode, go-mode, markdown-mode, helpful,
;; magit) nunca chegava a ser avaliado. Se quiser resolver completions "grudadas"
;; do eglot no futuro, isso se resolve de outra forma (ex: `eglot-booster` ou
;; simplesmente confiando no cache normal do capf), não com essa advice.

;;; --- Eglot ---
;; Garante que o Eglot seja carregado e configure os hooks manualmente.
(use-package eglot
  :ensure nil
  :demand t
  :custom
  (eglot-autoshutdown t)
  (eglot-sync-connect 0)
  (eglot-report-progress t) ; mostra "Indexing..." etc na área de eco —
                             ; sem isso a conexão é 100% silenciosa e
                             ; parece que não fez nada enquanto conecta
  :config
  ;; Define os servidores LSP para cada modo.
  (add-to-list 'eglot-server-programs '((rust-mode rust-ts-mode) . ("rust-analyzer")))
  (add-to-list 'eglot-server-programs '((go-mode go-ts-mode) . ("gopls")))
  (add-to-list 'eglot-server-programs '((nix-mode nix-ts-mode) . ("nil")))
  (add-to-list 'eglot-server-programs '((lua-mode lua-ts-mode) . ("lua-language-server")))
  (add-to-list 'eglot-server-programs
               '((python-mode python-ts-mode) . ("pyright-langserver" "--stdio"))))

;; Inicia o Eglot automaticamente somente nos modos com servidor configurado
;; e dentro de um projeto que o servidor consegue descobrir.
(defun borba/rust-workspace-p ()
  (and (derived-mode-p 'rust-mode 'rust-ts-mode)
       (locate-dominating-file default-directory "Cargo.toml")))

(defun borba/eglot-ensure-for-supported-mode ()
  (when (memq major-mode
              '(rust-mode rust-ts-mode
                go-mode go-ts-mode
                nix-mode nix-ts-mode
                lua-mode lua-ts-mode
                python-mode python-ts-mode))
    (when (or (not (derived-mode-p 'rust-mode 'rust-ts-mode))
              (borba/rust-workspace-p))
      (eglot-ensure))))

(add-hook 'prog-mode-hook #'borba/eglot-ensure-for-supported-mode)

;;; --- Flymake (para exibir erros) ---
;; Ativa o Flymake em todos os buffers de programação.
(add-hook 'prog-mode-hook #'flymake-mode)

(use-package rust-mode
  :mode "\\.rs\\'"
  :hook (rust-mode . prettify-symbols-mode))

(use-package go-mode :mode "\\.go\\'")

(use-package nix-mode :mode "\\.nix\\'")
(use-package lua-mode :mode "\\.lua\\'")

(use-package apheleia
  :config
  (setf (alist-get 'rust-mode apheleia-mode-alist) 'rustfmt
        (alist-get 'rust-ts-mode apheleia-mode-alist) 'rustfmt
        (alist-get 'go-mode apheleia-mode-alist) 'goimports
        (alist-get 'go-ts-mode apheleia-mode-alist) 'goimports
        (alist-get 'nix-mode apheleia-mode-alist) 'alejandra
        (alist-get 'nix-ts-mode apheleia-mode-alist) 'alejandra
        (alist-get 'lua-mode apheleia-mode-alist) 'stylua
        (alist-get 'lua-ts-mode apheleia-mode-alist) 'stylua
        (alist-get 'python-mode apheleia-mode-alist) 'black
        (alist-get 'python-ts-mode apheleia-mode-alist) 'black)
  (setf (alist-get 'rustfmt apheleia-formatters) '("rustfmt" "--emit" "stdout")
        (alist-get 'goimports apheleia-formatters) '("goimports")
        (alist-get 'alejandra apheleia-formatters) '("alejandra" "--quiet" "-")
        (alist-get 'stylua apheleia-formatters)
        '("stylua" "--stdin-filepath" filepath "-")
        (alist-get 'black apheleia-formatters) '("black" "--quiet" "-"))
  (apheleia-global-mode 1))

(use-package markdown-mode
  :mode ("README\\.md\\'" . gfm-mode)
  :mode ("\\.md\\'" . markdown-mode)
  :init (setq markdown-fontify-code-blocks-natively t)
  :hook ((markdown-mode . visual-line-mode)
         (gfm-mode . visual-line-mode)))

(use-package helpful
  :bind (("C-h f" . helpful-callable)
         ("C-h v" . helpful-variable)
         ("C-h k" . helpful-key)))

;; magit-log-arguments: log de commits com grafo/decoração/cor por padrão
;; (é como um `git log --graph --decorate --color` já aberto).
;; magit-diff-refine-hunk: destaca as palavras que mudaram DENTRO da
;; linha modificada, não só a linha inteira — bem mais fácil de ler.
;; magit-process-connection-type nil: evita alocar um pty por subprocesso
;; git; deixa o Magit visivelmente mais rápido (mais notável em macOS),
;; só custo é não poder responder prompt de senha interativo do git por
;; dentro do Magit (uso normal com SSH/credential-helper não é afetado).
(use-package magit
  :bind (("C-c g" . magit-status))
  :custom
  (magit-log-arguments '("-n256" "--graph" "--decorate" "--color"))
  (magit-diff-refine-hunk t)
  (magit-process-connection-type nil))

;; `M-x shell`/`eshell` não interpretam escapes ANSI de cor nem os
;; hyperlinks OSC 8 que o `cargo` emite (o `^[[...`/`^[]8;;...` cru que
;; apareceu na tela). `eat` é um emulador de terminal de verdade — usa
;; `M-x eat` e roda `cargo run` lá dentro.
(use-package eat :bind (("C-c t" . eat)))

;; consult: comandos de busca/navegação (linha, buffer, ripgrep, imenu,
;; histórico do kill-ring) que usam o mesmo vertico/orderless de cima
;; pra filtrar — é o "verbo" que faltava pro vertico já instalado.
(use-package consult
  :bind (("C-s" . consult-line)
         ("C-x b" . consult-buffer)
         ("M-y" . consult-yank-pop)
         ("C-c i" . consult-imenu)
         ("C-c r" . consult-ripgrep)))

;; embark: ações contextuais sobre o que estiver sob o cursor ou
;; selecionado no minibuffer (abrir, matar buffer, exportar um resultado
;; de busca pra um grep-edit editável). embark-consult conecta os dois.
(use-package embark
  :bind (("C-." . embark-act)
         ("C-;" . embark-dwim)))
(use-package embark-consult
  :after (embark consult)
  :hook (embark-collect-mode . consult-preview-at-point-mode))

;; which-key: depois de apertar um prefixo (C-c, C-x...) mostra num
;; popup os bindings disponíveis, em vez de precisar decorar tudo.
(use-package which-key
  :demand t
  :config
  (which-key-mode 1))

;; diff-hl: marca na fringe quais linhas mudaram/foram adicionadas/
;; removidas em relação ao git enquanto você edita — complementa o
;; magit, que só mostra isso no status/diff.
(use-package diff-hl
  :demand t
  :config
  (global-diff-hl-mode 1)
  (add-hook 'magit-post-refresh-hook #'diff-hl-magit-post-refresh))

;; hl-todo: destaca TODO/FIXME/HACK/XXX nos comentários com cor, pra não
;; passar batido lendo o código.
(use-package hl-todo
  :demand t
  :config
  (global-hl-todo-mode 1))

;; yaml-mode/toml-mode: highlight e indentação decentes pros arquivos
;; que você mais mexe fora de código de verdade (Cargo.toml, CI yaml,
;; sops secrets.yaml).
(use-package yaml-mode)
(use-package toml-mode)

;; rainbow-delimiters: colore parênteses/colchetes/chaves por nível de
;; aninhamento — ajuda em Rust e principalmente em elisp/nix.
(use-package rainbow-delimiters
  :hook (prog-mode . rainbow-delimiters-mode))

;; avy: pula o cursor pra qualquer palavra/caractere visível na tela com
;; 2-3 teclas, sem contar linhas nem soltar o teclado.
(use-package avy
  :bind (("C-'" . avy-goto-char-timer)))

;; tempel: snippets minimalistas (sintaxe é só lista de Emacs Lisp, sem
;; linguagem de template própria) que entram no mesmo
;; completion-at-point-functions do cape/corfu — não é mais um motor de
;; completion rodando em paralelo.
(use-package tempel
  :bind (("M-+" . tempel-complete)
         ("M-*" . tempel-insert))
  :init
  (add-hook 'completion-at-point-functions #'tempel-expand))

;; dape: debugger integrado (Debug Adapter Protocol), mesmo ecossistema
;; do eglot. Config de Go abaixo usa `dlv` (incluso no home.packages de
;; emacs-vanilla.nix): go-test/go-run-main rodam local; go-devspace/
;; go-attach são pra anexar num processo remoto já rodando com
;; `dlv ... --headless --listen=host:porta` — ajuste host/porta antes de
;; usar essas duas. Rust precisa de um adapter separado (`codelldb`, não
;; empacotado aqui por padrão) — quando for configurar, veja
;; `M-x customize-variable RET dape-configs`.
(use-package dape
  :init
  ;; Layout das janelas do debugger: o painel de Locals (primeiro
  ;; "dape info buffer") ocupa a maior parte da altura; os outros dois
  ;; ficam menores, empilhados do lado.
  (add-to-list 'display-buffer-alist '((category . dape-info-0)
                                        (display-buffer-in-side-window)
                                        (window-height . 0.8)
                                        (window-width . 0.3)))
  (add-to-list 'display-buffer-alist '((category . dape-info-1)
                                        (display-buffer-in-side-window)
                                        (window-height . 0.2)
                                        (window-width . 0.3)))
  (add-to-list 'display-buffer-alist '((category . dape-info-2)
                                        (display-buffer-in-side-window)
                                        (window-height . 0.1)
                                        (window-width . 0.3)))

  (setq
   dape-buffer-window-arrangement 'right
   dape-info-variable-table-aligned t
   dape-info-variable-table-row-config '((name . 20) (value . 80) (type . 0))
   dape-inlay-hints t
   dape-variable-auto-expand-alist '((0 . 3))) ; 0 é o primeiro buffer (Locals)

  (setq dape-configs
        '((go-test
           modes (go-mode go-ts-mode)
           command "dlv"
           command-args ("dap" "--listen" "127.0.0.1::autoport")
           command-cwd dape-command-cwd
           port :autoport
           :request "launch"
           :mode "test"
           :type "go"
           :program ".")

          (go-run-main
           modes (go-mode go-ts-mode)
           ensure dape-ensure-command
           command "dlv"
           command-args ("dap" "--listen" "127.0.0.1::autoport")
           command-cwd dape-command-cwd
           command-insert-stderr t
           port :autoport
           :args [""] ;; Args pro programa
           :cwd "."
           :name "Run Go app"
           :program "." ;; Usa "./cmd" se o main estiver em ./cmd/main.go
           :request "launch"
           :type "go")

          (go-devspace
           modes (go-mode go-ts-mode)
           host "127.0.0.1"
           port 2345 ;; ajustar pra porta real exposta pelo devspace/pod
           prefix-local (lambda () default-directory)
           prefix-remote "/workspace/"
           :name "Debug remote in devspace pod"
           :request "attach"
           :mode "remote"
           :type "go"
           command "dlv"
           command-args ("connect" "127.0.0.1:2345"))

          (go-attach
           modes (go-mode go-ts-mode)
           host "127.0.0.1"
           ;; Porta exposta por algo como:
           ;; dlv attach $(lsof -i TCP -s TCP:LISTEN -nP | awk '/:PORTA/ { print $2 }') --headless --listen=127.0.0.1:5005
           port 5005 ;; ajustar pra porta real do --listen
           :name "Attach to running Go process"
           :type "go"
           :request "attach"
           :mode "remote"
           :cwd (project-root (project-current))
           command "dlv"
           command-args ("connect" "127.0.0.1:5005"))))

  (defvar-keymap dape-session-map
    :doc "Dape keymap for blazingly fast navigation."
    "b" #'dape-breakpoint-toggle
    "c" #'dape-continue
    "i" #'dape-step-in
    "n" #'dape-next
    "o" #'dape-step-out
    "p" #'dape-pause
    "q" #'dape-quit
    "r" #'dape-restart)

  :config
  (add-hook 'dape-start-hook
            (lambda ()
              (use-local-map (copy-keymap dape-session-map))))
  (add-hook 'dape-stopped-hook
            (lambda ()
              (use-local-map (default-value 'keymap)))))

(defun borba/format-buffer ()
  "Format the current buffer."
  (interactive)
  (if (bound-and-true-p eglot--managed-mode)
      (eglot-format-buffer)
    (message "No Eglot formatter is active.")))

(global-set-key (kbd "C-c f") #'borba/format-buffer)

(when (file-exists-p custom-file)
  (load custom-file nil 'nomessage))

;;; init.el ends here
